#pragma once
#include <SDL/SDL.h>
#include <GL\glew.h>
#include <iostream>
#include <string>
using namespace std;

class GameDisplay       
{
public:
	GameDisplay(); //Class Constructor
	~GameDisplay();	//Class Destructor
	void InitialiseGameDisplay(); //Initialises the Game Display	
	void ChangeBuffer(); //Swaps the buffer to the Game Display
	void ClearDisplay(float r, float g, float b, float a); //color of clear

														 
	float GetDisplayWidth();    // Getter for the Display Width
	float GetDisplayHeight();   // Getter for the Display Width


private:

	void ReturnError(std::string eString); //Error return
	SDL_Window* GameWindow; //Holds Window Pointer
	SDL_GLContext Gamecontext; //Game Context object
						   
	float ScreenWidth;   // ScreenWidth
	float ScreenHeight;  // ScreenHeight


};

