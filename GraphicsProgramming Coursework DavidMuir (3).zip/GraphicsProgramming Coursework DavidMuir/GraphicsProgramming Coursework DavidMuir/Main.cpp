#include <SDL/SDL.h>
#include <iostream>
#include "MainGame.h"

int main(int argc, char** argv) //main game loop
{
	MainGame maingame; //new game object is greated
	maingame.RunGame(); //game runs

	return 0;
}
