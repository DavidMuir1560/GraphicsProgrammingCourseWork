#pragma once

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <SDL\SDL.h>
#include "GameDisplay.h"
using namespace glm;
struct CameraManager
{
public:
	CameraManager() // Class Constructor
	{

	};
	void InitialiseCamera(const vec3& Position, float FOV, float Aspect, float NearClip, float FarClip)  //The Camera Values are set to Parameters
	{
		this->CameraPosition = Position;    // Camera Position
		this->CameraForward= vec3(0.0f, 0.0f, 1.0f);   // Camera Forward Vector
		this->CameraUp = vec3(0.0f, 1.0f, 0.0f);       // Camera Up Vector
		this->ProjectionMatrix = perspective(FOV, Aspect, NearClip, FarClip);   // Projection Matrix for the Camera
	}

	inline glm::mat4 GetViewProjectionMatrix() const // Getter that returns the Camera's Projection Matrix
	{
		return ProjectionMatrix * lookAt(CameraPosition, CameraPosition + CameraForward, CameraUp);
	}


	void UpdateCamera(float Width, float Height) //Updates camera projection matrix
	{
		ProjectionMatrix = perspective(radians(45.0f), Width / Height, 0.01f, 1000.0f); //The Projection matrix is updated
	}


	void MouseControl()	// Allows the mouse to control where the camera is looking
	{

		GLfloat CurrentFrame = SDL_GetTicks(); //Current frame millseconds
		DeltaTime = CurrentFrame - LastFrame; //Calculates the Delta time 
		LastFrame = CurrentFrame; //Sets the Last Frame equal to the current frame

		//CameraSpeed = 1.0f * DeltaTime; //Calculates the Cameras 

		int MouseXPosition; //The Current X Position of the Mouse
		int	MouseYPosition; //The Current Y Position of the Mouse
		SDL_GetGlobalMouseState(&MouseXPosition, &MouseYPosition); //Saves the Mouse Details to these variables

		GLfloat XOffset = MouseXPosition - LastXPosition; //X Position Offset
		GLfloat YOffset = LastYPosition - MouseYPosition; //Y Position Offset 
		LastXPosition = MouseXPosition; //last x position is set equal to the current x position
		LastYPosition = MouseYPosition; //last y position is set equal to the current y position

		GLfloat Sensitivity = 0.15f; // Sensitivty of the mouse movements
							 
		                    
		XOffset *= Sensitivity;   // Offsets are lowered with the sensitivty 
		YOffset *= Sensitivity;

		// Camera Yaw and Pitch are calculated using the Offsets
		CameraYaw += XOffset;
		CameraPitch -= YOffset;

		vec3 CameraFront; // Temporary Vector 
		CameraFront.x = cos(radians(CameraYaw)) * cos(radians(CameraPitch)); //Rotation for X,Y and Z
		CameraFront.y = sin(radians(CameraPitch));
		CameraFront.z = sin(radians(CameraYaw)) * cos(radians(CameraPitch));
		CameraForward = normalize(CameraFront); //Forward Vector is set equal to the Normalised Front Vector


	}




	void MoveCameraForward(float Movement) //Moves the Camera forward
	{
		CameraPosition += CameraForward * Movement;
	}

	void MoveCameraBackwards(float Movement) //Moves the Camera backwards
	{
		CameraPosition -= CameraForward * Movement;
	}

	void MoveCameraRight(float Movement) //Moves the Camera to the right
	{
		CameraPosition -= cross(CameraUp, CameraForward) * Movement;
	}

	void MoveCameraLeft(float Movement) //Moves the Camera to the left
	{
		CameraPosition += cross(CameraUp, CameraForward) * Movement;
	}

	

	glm::vec3 CameraForward; //Camera Forward Vector


private:
	glm::mat4 ProjectionMatrix; //Projection Matrix
	glm::vec3 CameraPosition; //Camera Position
	glm::vec3 CameraUp;	//Camera Up Vector


	float LastXPosition = 334; //Last X Postion
	float LastYPosition = 512;	//Last Y Position

	float CameraYaw; //The Yaw of the Camera
	float CameraPitch;	//The Pitch of the Camera
	float DeltaTime = 0.0f;	//DeltaTime
	float LastFrame = 0.0f;	//Last frame
	//float CameraSpeed = 1.0f;	//Camera Movement Speed

	GameDisplay* GameWindow;	//Game Window Pointer
};