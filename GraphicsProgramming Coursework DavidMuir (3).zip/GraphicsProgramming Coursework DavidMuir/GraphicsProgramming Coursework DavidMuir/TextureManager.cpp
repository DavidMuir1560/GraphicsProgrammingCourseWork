#include "TextureManager.h"
#include "stb_image.h"
#include <cassert>
#include <iostream>


TextureManager::TextureManager(const std::string& fileName)
{
	
	int ImageWidth;  // Width of the Image
	int ImageHeight; // Height of the Image
	int ImageID;     // Image ID

	unsigned char* ImageDetails = stbi_load((fileName).c_str(), &ImageWidth, &ImageHeight, &ImageID, 4); //loads image from file

	if (ImageDetails == NULL)
	{
		std::cerr << "texture load failed" << fileName << std::endl; //if image data is null then prompts erros
	}

	glGenTextures(1, &TextureHandler);                            //Number of Textures and their address
	glBindTexture(GL_TEXTURE_2D, TextureHandler);                 //Bind the Texture  (Texture Type and the specific Texture being Binded)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); // Wrap Texture outside width
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); //Wrap Texture outside height
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); //Texture filterning for minification (texture is smaller than the area)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //Texture filtering for magnification(texture is larger than the area)
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ImageWidth, ImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, ImageDetails);	//Send the Texture to the GPU
								
	stbi_image_free(ImageDetails);   //Delete the Image Details from the CPU


}


TextureManager::~TextureManager()
{
	//Deletes the textures
	glDeleteTextures(1, &TextureHandler); //Number of textures and their address
}

void TextureManager::BindTexture(unsigned int unit)
{
	assert(unit >= 0 && unit <= 31); //Checks to see if we are working with 1 of the 32 textures

	glActiveTexture(GL_TEXTURE0 + unit);   // Sets the Active texture unit
	glBindTexture(GL_TEXTURE_2D, TextureHandler); // Type of Texture and the specific Texture to bind to the unit

}