#include "ObjectMesh.h"


ObjectMesh::ObjectMesh()   // Class Constructor
{

}

ObjectMesh::~ObjectMesh()     // Class Destructor
{
	glDeleteVertexArrays(1, &VertexArrayObject); //Deletes the Vertex Array Object Data
}

void ObjectMesh::InitialiseMesh(ObjectVertex * vertices, unsigned int NumberofVertices, unsigned int * indices, unsigned int NumberofIndices)
{
	IndexedModel Mod; // New Model object

					  //Loops through the amount of vertices and adds the models vertex data 
	for (unsigned int i = 0; i < NumberofVertices; i++)
	{
		Mod.positions.push_back(*vertices[i].GetPosition());
		Mod.texCoords.push_back(*vertices[i].GetTextureCoord());
		Mod.normals.push_back(*vertices[i].GetNorm());


	}

	for (unsigned int i = 0; i < NumberofIndices; i++)
		Mod.indices.push_back(indices[i]);

	Initialise3DModel(Mod); //Initialises the 3D Models

}

void ObjectMesh::Load3DModel(const std::string & filename)
{
	IndexedModel Mod = OBJModel(filename).ToIndexedModel(); //3D Model is loaded from file 
	Initialise3DModel(Mod); //Initialises the Model

}

void ObjectMesh::Initialise3DModel(const IndexedModel & model)
{
	DrawCount = model.indices.size();

	glGenVertexArrays(1, &VertexArrayObject);    //Generates a Vertex Array and stores it in the Vertex Array Object
	glBindVertexArray(VertexArrayObject); //Binds the Vertex Array object

	glGenBuffers(NUM_BUFFER, VertexArrayBuffer); //Generates buffers 

	glBindBuffer(GL_ARRAY_BUFFER, VertexArrayBuffer[POSITION_VERTEXBUFFER]); //Tells Opengl to bind the buffers.Takes in what type of data the buffer carries and passes the data
	glBufferData(GL_ARRAY_BUFFER, model.positions.size() * sizeof(model.positions[0]), &model.positions[0], GL_STATIC_DRAW); ////Moves the Data to the GPU. Defines the type of data, it's size, the starting address of the data and where the data is going to be stored
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

	glBindBuffer(GL_ARRAY_BUFFER, VertexArrayBuffer[TEXTURECOORDS_VB]); //Tells Opengl to bind the buffers.Takes in what type of data the buffer carries and passes the data
	glBufferData(GL_ARRAY_BUFFER, model.texCoords.size() * sizeof(model.texCoords[0]), &model.texCoords[0], GL_STATIC_DRAW); //Moves the Data to the GPU. Defines the type of data, it's size, the starting address of the data and where the data is going to be stored
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);

	glBindBuffer(GL_ARRAY_BUFFER, VertexArrayBuffer[NORMAL_VB]);                                                          //Tells Opengl to bind the buffers.Takes in what type of data the buffer carries and passes the data
	glBufferData(GL_ARRAY_BUFFER, sizeof(model.normals[0]) * model.normals.size(), &model.normals[0], GL_STATIC_DRAW);    //Moves the Data to the GPU. Defines the type of data, it's size, the starting address of the data and where the data is going to be stored
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, 0);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, VertexArrayBuffer[INDEX_VB]);                                                         //Moves the Data to the GPU. Defines the type of data, it's size, the starting address of the data and where the data is going to be stored
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, model.indices.size() * sizeof(model.indices[0]), &model.indices[0], GL_STATIC_DRAW);  //Moves the Data to the GPU. Defines the type of data, it's size, the starting address of the data and where the data is going to be stored

	glBindVertexArray(0); //Unbinds the Vertex Array Object
}

void ObjectMesh::DrawMesh()
{
	glBindVertexArray(VertexArrayObject); //Binds the Vertex Array
	glDrawElements(GL_TRIANGLES, DrawCount, GL_UNSIGNED_INT, 0); //Draws the objects Polygons
	glBindVertexArray(0); //unbinds vertex array

}
