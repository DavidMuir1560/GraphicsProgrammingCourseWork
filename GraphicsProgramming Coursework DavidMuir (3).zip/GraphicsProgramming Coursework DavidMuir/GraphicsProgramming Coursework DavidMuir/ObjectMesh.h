#pragma once
#include <glm\glm.hpp>
#include <GL\glew.h>
#include <string>
#include <vector>
#include "obj_loader.h"
#include "TransformManager.h"
class ObjectVertex //vertex object
{
public:
	ObjectVertex(const glm::vec3& pos, const glm::vec2& texCoord, const glm::vec3& normal = glm::vec3(0, 0, 0)) //constructor
	{
		//Sets values to constructor parameters
		this->Position = pos;
		this->TextureCoordinates = texCoord;
		this->Normals = normal;

	}

	glm::vec3 Position; // Position
	glm::vec2 TextureCoordinates; //Texture coordinates
	glm::vec3 Normals; //Normals

					
	glm::vec3* GetPosition() { return &Position; }                // Get Position
	glm::vec2* GetTextureCoord() { return &TextureCoordinates; }  // Get Texture Coordinates
	glm::vec3* GetNorm() { return &Normals; }                     // Get Normals

protected:
private:


};

class ObjectMesh //Mesh object
{
public:
	ObjectMesh(); //Constructor
	~ObjectMesh(); //Destructor
	
	void DrawMesh(); //Draw the Object mesh
	void InitialiseMesh(ObjectVertex* vertices, unsigned int numVertices, unsigned int* indices, unsigned int numIndices); //Initialise mesh data
	void Load3DModel(const std::string& filename); //Load 3D Model object from File
	void Initialise3DModel(const IndexedModel& model); //Initialises model values



private:

	//Buffer enums
	enum
	{
		POSITION_VERTEXBUFFER,
		TEXTURECOORDS_VB,
		NORMAL_VB,
		INDEX_VB,
		NUM_BUFFER
	};

	GLuint VertexArrayObject;	             //The Vertex array objects
	GLuint VertexArrayBuffer[NUM_BUFFER];    //Creates the array of buffers
	unsigned int DrawCount;                  //How much of the VertexArrayObject is going to be drawn


};

