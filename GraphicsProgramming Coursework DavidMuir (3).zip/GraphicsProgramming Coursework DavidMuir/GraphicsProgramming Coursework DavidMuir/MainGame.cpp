#include "MainGame.h"	//includes class header and libraries
#include <iostream>
#include <string>


TransformManager ObjectTransform;    // Transform of the Objects
TransformManager ObjectTransform2;   // Transform of the Objects
TransformManager ObjectTransform3;   // Transform of the Objects

MainGame::MainGame()
{
	GameState = State::PLAY;	//The Game state is set to play
	GameDisplay* GameScreen = new GameDisplay();	//A New display is created
						
	ObjectMesh* ModelMesh1();   // Model Mesh Object
	ObjectMesh* ModelMesh2();   // Model Mesh Object
	ObjectMesh* ModelMesh3();   // Model Mesh Object

	CameraManager* MainCamera();   // Camera Object


}


MainGame::~MainGame()
{
}

void MainGame::RunGame()
{
	StartSystems(); //Initialise the Game
	GameCycle();	//Starts the Game cycle

}

void MainGame::StartSystems()
{
	GameScreen.InitialiseGameDisplay();	//Game display is Created

			
	ModelMesh1.Load3DModel("A:\\Graphics Programming\\Working Coursework\\GraphicsProgramming Coursework DavidMuir\\GraphicsProgramming Coursework DavidMuir\\res\\WoodenTable.obj");     // 3D Model is loaded from file
	ModelMesh2.Load3DModel("A:\\Graphics Programming\\Working Coursework\\GraphicsProgramming Coursework DavidMuir\\GraphicsProgramming Coursework DavidMuir\\res\\Shield.obj");          // 3D Model is loaded from file
	ModelMesh3.Load3DModel("A:\\Graphics Programming\\Working Coursework\\GraphicsProgramming Coursework DavidMuir\\GraphicsProgramming Coursework DavidMuir\\res\\Rock_10.obj");         // 3D Model is loaded from file

	//Sets the transforms for each of the objects
	ObjectTransform.SetPosition(glm::vec3(-0, 0, 5));
	ObjectTransform.SetRotation(glm::vec3(25, 90, 25));
	ObjectTransform.SetScale(glm::vec3(1.5, 1.5, 1.5));

	ObjectTransform2.SetPosition(glm::vec3(-0.0f, 0, 0.0f));
	ObjectTransform2.SetRotation(glm::vec3(0, -190, 0));
	ObjectTransform2.SetScale(glm::vec3(1, 1, 1));

	ObjectTransform3.SetPosition(glm::vec3(-0.0f, 0, 0));
	ObjectTransform3.SetRotation(glm::vec3(.0, 180, 45));
	ObjectTransform3.SetScale(glm::vec3(0.75, 0.75, 0.75));

	//The Game Camera is created
	MainCamera.InitialiseCamera(glm::vec3(-20, -15, 0), 70.0f,
		(float)GameScreen.GetDisplayWidth() / GameScreen.GetDisplayHeight(), 0.01f, 1000.0);

	


}

void MainGame::RegisterInput()
{
	SDL_Event sdlEvent; //New Event object

	while (SDL_PollEvent(&sdlEvent)) //While events are being processed
	{
		switch (sdlEvent.type) //Switch dependant on the type of event
		{
		case SDL_QUIT:   // If SDL_QUIT is called
			GameState = State::EXIT; //Quit the game
			break;

			//When a key is pressed
		case SDL_KEYDOWN:
			switch (sdlEvent.key.keysym.sym)
			{
				//Camera Movement


			case SDLK_w:   // If the user presses W
				MainCamera.MoveCameraForward(1);   // Move the Camera Forward
				break;
			case SDLK_s:   // If the user presses S
				MainCamera.MoveCameraBackwards(1);  // Move the Camera Backwards
				break;
			case SDLK_d:   // If the user presses D
				MainCamera.MoveCameraRight(1);      // Move the Camera Right
				break;
			case SDLK_a:   // If the user presses A  
				MainCamera.MoveCameraLeft(1);       // Move the Camera Left
				break;

				//Object Rotation
			case SDLK_UP:  // If the user presses the Up Arrow
				ObjectTransform.Rotate(vec3(0.1, 0, 0)); // Rotate the Object
				break;

			case SDLK_DOWN: // If the user presses the Down Arrow
				ObjectTransform.Rotate(-vec3(0.1, 0, 0)); // Rotate the Object
				break;

			case SDLK_LEFT: // If the user presses the Left Arrow
				ObjectTransform.Rotate(-vec3(0, 0.1, 0)); // Rotate the Object
				break;
			case SDLK_RIGHT: // If the user presses the Right Arrow
				ObjectTransform.Rotate(vec3(0, 0.1, 0)); // Rotate the Object
				break;

				
			case SDLK_ESCAPE:   // If the user presses the Escape Key
				GameState = State::EXIT;   // Quit the game 
				break;


			}
		}
		MainCamera.MouseControl(); //Move the Camera with the mouse
	}
}

void MainGame::GameCycle()
{
	while (GameState != State::EXIT) //while the state is not exit
	{
		RegisterInput();	//Input is handled
		MainCamera.UpdateCamera(GameScreen.GetDisplayWidth(), GameScreen.GetDisplayHeight());	//camera is updated
		UpdateGame();	//Draws the Scene
	}
}

void MainGame::UpdateGame()
{
	GameScreen.ClearDisplay(0.5f, 0.5f, 0.5f, 1.0f); //Clear display


	ShaderManager Shader1("A:\\Graphics Programming\\Working Coursework\\GraphicsProgramming Coursework DavidMuir\\GraphicsProgramming Coursework DavidMuir\\res\\shaderNew"); //Shader object
	TextureManager ModelTexture1("A:\\Graphics Programming\\Working Coursework\\GraphicsProgramming Coursework DavidMuir\\GraphicsProgramming Coursework DavidMuir\\res\\WoodTexture.jpg");	//Texture object

	ModelTexture1.BindTexture(0);//Binds the texture
	Shader1.BindShader();//Binds the shader
	Shader1.UpdateShaders(ObjectTransform, MainCamera); // Updates the objects transform and Camera 


	ModelMesh1.DrawMesh();//Draws the Mesh

	ShaderManager Shader2("A:\\Graphics Programming\\Working Coursework\\GraphicsProgramming Coursework DavidMuir\\GraphicsProgramming Coursework DavidMuir\\res\\shaderNew"); //Shader object
	TextureManager ModelTexture2("A:\\Graphics Programming\\Working Coursework\\GraphicsProgramming Coursework DavidMuir\\GraphicsProgramming Coursework DavidMuir\\res\\ShieldTexture.jpg");//Texture object

	ModelTexture2.BindTexture(2); // Binds the Texture
	Shader2.BindShader(); //Binds the shader
	Shader2.UpdateShaders(ObjectTransform2, MainCamera); // Updates the Objects transform and Camera


	ModelMesh2.DrawMesh();  // Draws the Mesh

	ShaderManager Shader3("A:\\Graphics Programming\\Working Coursework\\GraphicsProgramming Coursework DavidMuir\\GraphicsProgramming Coursework DavidMuir\\res\\shaderNew"); //Shader object
	TextureManager ModelTexture3("A:\\Graphics Programming\\Working Coursework\\GraphicsProgramming Coursework DavidMuir\\GraphicsProgramming Coursework DavidMuir\\res\\RockTexture.jpg");//Texture object


	ModelTexture3.BindTexture(0); // Binds the Texture
	Shader3.BindShader();  // Binds the Shader
	Shader3.UpdateShaders(ObjectTransform3, MainCamera);  // Updates the Objects transform and Camera


	ModelMesh3.DrawMesh(); // Draws the Mesh

	
	glEnableClientState(GL_COLOR_ARRAY); //Sets colour states
	glEnd(); //Ends the Opengl Render pass



	GameScreen.ChangeBuffer(); //Buffers are swapped to the Game Display

}

