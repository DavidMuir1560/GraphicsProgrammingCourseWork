#pragma once
#include <string>
#include <GL\glew.h>
#include "TransformManager.h"
#include "CameraManager.h"
class ShaderManager
{
public:
	ShaderManager(const std::string& filename); //Class Constructor
	~ShaderManager(); //Class Destructor

	std::string LoadShader(const std::string& fileName); //Loads the shaders from file

	GLuint CreateShader(const std::string& text, unsigned int type); //Creates the shader

	void CheckShaderError(GLuint shader, GLuint flag, bool isProgram, const std::string& errorMessage); //Checks for errors in the Shaders
	
	void BindShader(); //Set GPU to use the shaders

	void UpdateShaders(const TransformManager& trans, const CameraManager& camera); //Updates shader data

	
	
	
	
	
	



protected:
private:
	static const unsigned int NUM_OF_SHADERS = 2; // Number of shaders

												  //Uniform enums
	enum
	{
		TRANSFORM_UNIF,
		CAMDIRECTION_UNIF,

		NUM_OF_UNIFORMS
	};

	GLuint Program; // Track the shader program
	GLuint Shaders[NUM_OF_SHADERS]; //Array of shaders
	GLuint Uniforms[NUM_OF_UNIFORMS]; //Number of uniforms
};


