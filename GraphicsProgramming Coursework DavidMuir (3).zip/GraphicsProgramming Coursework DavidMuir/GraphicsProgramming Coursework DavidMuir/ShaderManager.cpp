#include "ShaderManager.h"
#include <iostream>
#include <fstream>

ShaderManager::ShaderManager(const std::string & filename)
{
	//Creates the shader program and the shaders
	Program = glCreateProgram();
	Shaders[0] = CreateShader(LoadShader(filename + ".vert"), GL_VERTEX_SHADER);   // Loads the vert Shader from file
	Shaders[1] = CreateShader(LoadShader(filename + ".frag"), GL_FRAGMENT_SHADER); // Loads the Frag shader from file

	//Attaches the Shaders to the program
	for (int i = 0; i < NUM_OF_SHADERS; i++)
	{
		glAttachShader(Program, Shaders[i]);
	}

	//Binds the attributes to the shader
	glBindAttribLocation(Program, 0, "position");
	glBindAttribLocation(Program, 1, "textureCoord");
	glBindAttribLocation(Program, 2, "normal");

	glLinkProgram(Program); //Creates an executable that will run on the GPU shader
	CheckShaderError(Program, GL_LINK_STATUS, true, "Error: Shader Program linking failed"); //Checks for Errors

	glValidateProgram(Program); //Checks that the program is valid
	CheckShaderError(Program, GL_VALIDATE_STATUS, true, "Error: Shader program is not valid"); //Check for Error

																								  //Sets Location for Uniforms
	Uniforms[TRANSFORM_UNIF] = glGetUniformLocation(Program, "trans");      // Transform Uniforms
	Uniforms[CAMDIRECTION_UNIF] = glGetUniformLocation(Program, "camDirection");   // CamDirection Uniforms
}

ShaderManager::~ShaderManager()
{
	//Detaches and then Deletes the shaders
	for (int i = 0; i < NUM_OF_SHADERS; i++)
	{
		glDetachShader(Program, Shaders[i]); //Detaches the shaders from the Program
		glDeleteShader(Shaders[i]);


	}
	//Deletes program
	glDeleteProgram(Program);

}


void ShaderManager::BindShader()
{
	glUseProgram(Program); //Tells opengl to use shader program
}

std::string ShaderManager::LoadShader(const std::string& fileName)
{
	//file is declared and opened
	std::ifstream file;
	file.open((fileName).c_str());

	//strings for output and lines
	std::string output;
	std::string line;

	if (file.is_open()) //if file is open
	{
		while (file.good()) //while file is able to be parsed
		{
			getline(file, line); //gets the line data
			output.append(line + "\n"); //appends on output value
		}
	}
	else
	{
		std::cerr << "Unable to load shader: " << fileName << std::endl; //prompt
	}

	return output; //returns line output 
}

void ShaderManager::CheckShaderError(GLuint shader, GLuint flag, bool isProgram, const std::string& errorMessage)
{
	GLint success = 0; // success int
	GLchar error[1024] = { 0 }; //error array

	if (isProgram) //if it is a program
		glGetProgramiv(shader, flag, &success); //returns program parameter flag
	else
		glGetShaderiv(shader, flag, &success); //return shader parameter flag

	if (success == GL_FALSE) //if not success
	{
		if (isProgram)
			glGetProgramInfoLog(shader, sizeof(error), NULL, error); //gets program logs
		else
			glGetShaderInfoLog(shader, sizeof(error), NULL, error); //gets shader logs

		std::cerr << errorMessage << ": '" << error << "'" << std::endl; //promps message
	}
}

GLuint ShaderManager::CreateShader(const std::string & text, unsigned int type)
{
	GLuint shader = glCreateShader(type); //create shader based on specified type

	if (shader == 0) //if == 0 shader no created
		std::cerr << "Error type creation failed " << type << std::endl;

	const GLchar* stringSource[1]; //convert strings into list of c-strings
	stringSource[0] = text.c_str();
	GLint lengths[1];
	lengths[0] = text.length();

	glShaderSource(shader, 1, stringSource, lengths); //Sends source code to opengl
	glCompileShader(shader); //get open gl to compile shader code

	CheckShaderError(shader, GL_COMPILE_STATUS, false, "Error compiling shader!"); //Checks for a compile error

	return shader;
}

void ShaderManager::UpdateShaders(const TransformManager & transform, const CameraManager & Maincamera)
{
	glm::mat4 modelMat = Maincamera.GetViewProjectionMatrix() * transform.GetModel(); //Model View projection matrix is calculated
	glUniformMatrix4fv(Uniforms[TRANSFORM_UNIF], 1, GLU_FALSE, &modelMat[0][0]);		//Model Matrix Uniform is linked
	glUniform3f(Uniforms[CAMDIRECTION_UNIF], Maincamera.CameraForward.x, Maincamera.CameraForward.y, Maincamera.CameraForward.z); //camera direction uniform is linked
}


