#pragma once
//includes to appropriate libraries and header files
#include <SDL\SDL.h>
#include <GL/glew.h>
#include "GameDisplay.h" 
#include "ObjectMesh.h"
#include "ShaderManager.h"
#include "TextureManager.h"
#include "TransformManager.h"
#include "CameraManager.h"


enum class State { PLAY, EXIT }; // State of the Game

class MainGame	
{
public:
	MainGame(); //Constructor
	~MainGame();	//Destructor

	void RunGame(); //Runs the Game

private:
	void StartSystems();	//Creates the Window and initialises the Camera and Objects
	void RegisterInput();	//Registers and reacts to User Input
	void GameCycle();	// The Game Cycle
	void UpdateGame();	// Draws the Game

	GameDisplay GameScreen;	//Game Display Object
	State GameState;	//Game State

	ObjectMesh ModelMesh1;	
	ObjectMesh ModelMesh2;   // The Meshes that will be drawn
	ObjectMesh ModelMesh3;


	CameraManager MainCamera;	//The Camera Object

	
	float count = 0;
};

