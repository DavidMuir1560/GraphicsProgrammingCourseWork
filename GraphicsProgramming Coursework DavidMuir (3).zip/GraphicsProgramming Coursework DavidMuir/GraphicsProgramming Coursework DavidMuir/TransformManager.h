#pragma once

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>

struct TransformManager
{
public:
	
	TransformManager(const glm::vec3& Pos = glm::vec3(), const glm::vec3& Rot = glm::vec3(), const glm::vec3& Scale = glm::vec3(1.0f, 1.0f, 1.0f))
	{
		this->ObjectPosition = Pos;   // Sets the Object Position to the Pos parameter
		this->ObjectRotation = Rot;   // Sets the Object Rotation to the Rot parameter
		this->ObjectScale = Scale;    // Sets the Object Scale to the Scale parameter
	}

	inline glm::mat4 GetModel() const //Runs at compile time
	{
		//Calculates the Models matrixes
		glm::mat4 PositionMatrix = glm::translate(ObjectPosition);     // The Position Matrix
		glm::mat4 ScaleMatrix = glm::scale(ObjectScale);               // The Scale Matrix
		glm::mat4 XRotation = glm::rotate(ObjectRotation.x, glm::vec3(1.0, 0.0, 0.0));    
		glm::mat4 YRotation = glm::rotate(ObjectRotation.y, glm::vec3(0.0, 1.0, 0.0));
		glm::mat4 ZRotation = glm::rotate(ObjectRotation.z, glm::vec3(0.0, 0.0, 1.0)); 
		glm::mat4 RotationMatrix = XRotation * YRotation * ZRotation;        // The Rotation Matrix

		return PositionMatrix * RotationMatrix * ScaleMatrix;    
	}

	inline glm::vec3* GetPosition() { return &ObjectPosition; } //Gets the Objects Position
	inline glm::vec3* GetRotation() { return &ObjectRotation; } //Gets the Objects Rotation
	inline glm::vec3* GetScale() { return &ObjectScale; }       //Gets the objects Scale

	inline void SetPosition(glm::vec3& pos) { this->ObjectPosition = pos; } //Sets the Objects Position
	inline void SetRotation(glm::vec3& rot) { this->ObjectRotation = rot; } //Sets the Objects Rotation
	inline void SetScale(glm::vec3& scale) { this->ObjectScale = scale; }   //Sets the Objects Scale

	void Rotate(glm::vec3 & rotateAmount) //Rotates the object
	{
		ObjectRotation += rotateAmount;
	}
protected:
private:
	
	glm::vec3 ObjectPosition;     //Position
	glm::vec3 ObjectRotation;     //Rotation
	glm::vec3 ObjectScale;        //Scale
};

