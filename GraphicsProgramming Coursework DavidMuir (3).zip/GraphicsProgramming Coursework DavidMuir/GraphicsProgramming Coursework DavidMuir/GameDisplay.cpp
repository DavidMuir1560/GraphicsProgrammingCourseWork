#include "GameDisplay.h"



GameDisplay::GameDisplay()
{
	GameWindow = nullptr;		//Sets the GameWindow equal to the null pointer
	ScreenHeight = 768.0f;	//Screen height
	ScreenWidth = 1024.0f;	//Screen width

}


GameDisplay::~GameDisplay()
{
	SDL_GL_DeleteContext(Gamecontext); //Destroys the gl context
	SDL_DestroyWindow(GameWindow);	//Destroys the Game Window 
	SDL_Quit();	//Set SDL to quit
}

void GameDisplay::InitialiseGameDisplay()
{
	SDL_Init(SDL_INIT_EVERYTHING); //Initialise everything


	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);	//Sets attributes of SDL and GL
	GameWindow = SDL_CreateWindow("Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, (int)ScreenWidth, (int)ScreenHeight, SDL_WINDOW_OPENGL); //The Game window is created
	Gamecontext = SDL_GL_CreateContext(GameWindow); //Creates the gl context

	glEnable(GL_DEPTH_TEST); //Enable z-buffering 
	glEnable(GL_CULL_FACE); //Stops the game from drawing faces not in view of the camera


	GLenum error = glewInit();// Initialise glew

	if (GameWindow == nullptr)
	{
		ReturnError("window failed to create");
	}

	if (Gamecontext == nullptr)
	{
		ReturnError("SDL_GL context failed to create");
	}

	if (error != GLEW_OK)
	{
		ReturnError("GLEW failed to initialise");
	}

	glClearColor(0.0f, 1.0f, 1.0f, 1.0f); //Sets the background colour
}

void GameDisplay::ChangeBuffer()
{
	SDL_GL_SwapWindow(GameWindow); //Swaps the buffer to window
}

void GameDisplay::ClearDisplay(float r, float g, float b, float a)
{
	glClearColor(r, g, b, a);	//Clear colour is set
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  //The depths and colour buffers are used for Clear Display
}

float GameDisplay::GetDisplayWidth()
{
	return ScreenWidth; //Returns the screen width
}

float GameDisplay::GetDisplayHeight()
{
	return ScreenHeight;	//Returns the screen height
}

void GameDisplay::ReturnError(std::string eString)
{
	std::cout << eString << std::endl; //Returns an error message
	std::cout << "press any  key to quit...";	//Returns an message prompt
	int in;
	std::cin >> in;
	SDL_Quit(); // SDL Quits
}
